import { companies, Company } from '@/data/companies';
import { Link } from 'wouter';
import { useState } from 'react';

// Map quadrants to coordinates
const getPosition = (quadrant: string): { x: number; y: number } => {
  switch (quadrant) {
    case 'orchestrator': return { x: 75, y: 75 }; // High depth, high network
    case 'data-engine': return { x: 25, y: 75 }; // Low depth, high network
    case 'niche-expert': return { x: 75, y: 25 }; // High depth, low network
    case 'service-enabler': return { x: 25, y: 25 }; // Low depth, low network
    default: return { x: 50, y: 50 };
  }
};

// Add some variance to avoid exact overlaps
const addJitter = (value: number, seed: number): number => {
  const jitter = ((seed * 9301 + 49297) % 233280) / 233280 - 0.5;
  return value + jitter * 15;
};

export default function PositioningMatrix() {
  const [hoveredCompany, setHoveredCompany] = useState<Company | null>(null);

  const getThreatColor = (level: string) => {
    switch (level) {
      case 'structural': return 'oklch(0.65 0.22 25)';
      case 'hybrid': return 'oklch(0.65 0.22 25)';
      case 'network': return 'oklch(0.75 0.15 85)';
      case 'tactical': return 'oklch(0.65 0.18 155)';
      default: return 'oklch(0.55 0.20 230)';
    }
  };

  return (
    <div className="relative w-full h-[600px] bg-card rounded-lg border border-border p-8">
      {/* Axis Labels */}
      <div className="absolute top-4 left-1/2 -translate-x-1/2 text-sm font-semibold text-muted-foreground">
        Network Effects Strength
      </div>
      <div className="absolute bottom-4 left-1/2 -translate-x-1/2 text-sm font-semibold text-muted-foreground">
        Workflow Integration Depth
      </div>
      <div className="absolute left-4 top-1/2 -translate-y-1/2 -rotate-90 text-sm font-semibold text-muted-foreground origin-center">
        Network Effects
      </div>

      {/* SVG Matrix */}
      <svg className="w-full h-full" viewBox="0 0 100 100" preserveAspectRatio="xMidYMid meet">
        {/* Background grid */}
        <line x1="50" y1="10" x2="50" y2="90" stroke="oklch(0.25 0.03 240)" strokeWidth="0.2" strokeDasharray="1,1" />
        <line x1="10" y1="50" x2="90" y2="50" stroke="oklch(0.25 0.03 240)" strokeWidth="0.2" strokeDasharray="1,1" />
        
        {/* Quadrant labels */}
        <text x="25" y="25" fontSize="3" fill="oklch(0.60 0.02 240)" textAnchor="middle" fontWeight="600">
          Service Enablers
        </text>
        <text x="75" y="25" fontSize="3" fill="oklch(0.60 0.02 240)" textAnchor="middle" fontWeight="600">
          Niche Experts
        </text>
        <text x="25" y="85" fontSize="3" fill="oklch(0.60 0.02 240)" textAnchor="middle" fontWeight="600">
          Data Engines
        </text>
        <text x="75" y="85" fontSize="3" fill="oklch(0.60 0.02 240)" textAnchor="middle" fontWeight="600">
          Orchestrators
        </text>

        {/* Axis lines */}
        <line x1="10" y1="90" x2="90" y2="90" stroke="oklch(0.92 0.01 240)" strokeWidth="0.3" />
        <line x1="10" y1="10" x2="10" y2="90" stroke="oklch(0.92 0.01 240)" strokeWidth="0.3" />
        
        {/* Axis arrows */}
        <polygon points="90,90 88,89 88,91" fill="oklch(0.92 0.01 240)" />
        <polygon points="10,10 9,12 11,12" fill="oklch(0.92 0.01 240)" />

        {/* Company bubbles */}
        {companies.map((company, idx) => {
          const pos = getPosition(company.quadrant);
          const x = addJitter(pos.x, idx);
          const y = 100 - addJitter(pos.y, idx * 2); // Invert Y for SVG coordinates
          const radius = Math.sqrt(company.fundingAmount) / 15; // Scale by funding
          const color = getThreatColor(company.threatLevel);
          const isHovered = hoveredCompany?.id === company.id;

          return (
            <g key={company.id}>
              <Link href={`/company/${company.id}`}>
                <a>
                  <circle
                    cx={x}
                    cy={y}
                    r={isHovered ? radius * 1.2 : radius}
                    fill={color}
                    fillOpacity={isHovered ? 0.9 : 0.7}
                    stroke={isHovered ? 'oklch(0.98 0.01 240)' : color}
                    strokeWidth={isHovered ? 0.4 : 0.2}
                    className="cursor-pointer transition-all duration-200"
                    onMouseEnter={() => setHoveredCompany(company)}
                    onMouseLeave={() => setHoveredCompany(null)}
                  />
                  {(isHovered || company.fundingAmount > 500) && (
                    <text
                      x={x}
                      y={y - radius - 1}
                      fontSize="2.5"
                      fill="oklch(0.92 0.01 240)"
                      textAnchor="middle"
                      fontWeight="600"
                      className="pointer-events-none"
                    >
                      {company.name}
                    </text>
                  )}
                </a>
              </Link>
            </g>
          );
        })}
      </svg>

      {/* Hover tooltip */}
      {hoveredCompany && (
        <div className="absolute bottom-8 right-8 bg-popover border border-border rounded-lg p-4 shadow-xl max-w-xs z-10">
          <h3 className="font-bold text-lg mb-2">{hoveredCompany.name}</h3>
          <div className="space-y-1 text-sm">
            <div className="flex justify-between">
              <span className="text-muted-foreground">Funding:</span>
              <span className="font-mono text-success font-semibold">{hoveredCompany.funding}</span>
            </div>
            <div className="flex justify-between">
              <span className="text-muted-foreground">Headcount:</span>
              <span className="font-mono">{hoveredCompany.headcount}</span>
            </div>
            <div className="flex justify-between">
              <span className="text-muted-foreground">Threat:</span>
              <span className="capitalize font-medium">{hoveredCompany.threatLevel}</span>
            </div>
          </div>
          <p className="text-xs text-muted-foreground mt-2 border-t border-border pt-2">
            {hoveredCompany.coreProduct}
          </p>
        </div>
      )}

      {/* Legend */}
      <div className="absolute top-8 right-8 bg-card/80 backdrop-blur border border-border rounded-lg p-3 text-xs">
        <div className="font-semibold mb-2">Threat Level</div>
        <div className="space-y-1">
          <div className="flex items-center gap-2">
            <div className="w-3 h-3 rounded-full" style={{ backgroundColor: 'oklch(0.65 0.22 25)' }}></div>
            <span>Structural/Hybrid</span>
          </div>
          <div className="flex items-center gap-2">
            <div className="w-3 h-3 rounded-full" style={{ backgroundColor: 'oklch(0.75 0.15 85)' }}></div>
            <span>Network</span>
          </div>
          <div className="flex items-center gap-2">
            <div className="w-3 h-3 rounded-full" style={{ backgroundColor: 'oklch(0.65 0.18 155)' }}></div>
            <span>Tactical</span>
          </div>
        </div>
        <div className="mt-3 pt-2 border-t border-border text-muted-foreground">
          Bubble size = Funding
        </div>
      </div>
    </div>
  );
}
