import { useState, useMemo } from 'react';
import { Link } from 'wouter';
import { companies } from '@/data/companies';
import { Card } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Badge } from '@/components/ui/badge';
import { 
  ArrowLeft, 
  ArrowUpDown, 
  ArrowUp, 
  ArrowDown,
  Search,
  Filter,
  ExternalLink
} from 'lucide-react';

type SortField = 'name' | 'funding' | 'headcount' | 'category' | 'quadrant' | 'threat';
type SortDirection = 'asc' | 'desc';

export default function Companies() {
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedCategory, setSelectedCategory] = useState<string>('all');
  const [selectedQuadrant, setSelectedQuadrant] = useState<string>('all');
  const [selectedThreat, setSelectedThreat] = useState<string>('all');
  const [sortField, setSortField] = useState<SortField>('funding');
  const [sortDirection, setSortDirection] = useState<SortDirection>('desc');

  const handleSort = (field: SortField) => {
    if (sortField === field) {
      setSortDirection(sortDirection === 'asc' ? 'desc' : 'asc');
    } else {
      setSortField(field);
      setSortDirection('desc');
    }
  };

  const filteredAndSortedCompanies = useMemo(() => {
    let filtered = companies.filter(company => {
      const matchesSearch = company.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
                           company.coreProduct.toLowerCase().includes(searchQuery.toLowerCase()) ||
                           company.headquarters.toLowerCase().includes(searchQuery.toLowerCase());
      const matchesCategory = selectedCategory === 'all' || company.category === selectedCategory;
      const matchesQuadrant = selectedQuadrant === 'all' || company.quadrant === selectedQuadrant;
      const matchesThreat = selectedThreat === 'all' || company.threatLevel === selectedThreat;
      return matchesSearch && matchesCategory && matchesQuadrant && matchesThreat;
    });

    // Sort
    filtered.sort((a, b) => {
      let comparison = 0;
      switch (sortField) {
        case 'name':
          comparison = a.name.localeCompare(b.name);
          break;
        case 'funding':
          comparison = a.fundingAmount - b.fundingAmount;
          break;
        case 'headcount':
          comparison = a.headcountNumber - b.headcountNumber;
          break;
        case 'category':
          comparison = a.category.localeCompare(b.category);
          break;
        case 'quadrant':
          comparison = a.quadrant.localeCompare(b.quadrant);
          break;
        case 'threat':
          comparison = a.threatLevel.localeCompare(b.threatLevel);
          break;
      }
      return sortDirection === 'asc' ? comparison : -comparison;
    });

    return filtered;
  }, [companies, searchQuery, selectedCategory, selectedQuadrant, selectedThreat, sortField, sortDirection]);

  const SortIcon = ({ field }: { field: SortField }) => {
    if (sortField !== field) return <ArrowUpDown className="h-4 w-4 ml-1 opacity-40" />;
    return sortDirection === 'asc' 
      ? <ArrowUp className="h-4 w-4 ml-1 text-primary" />
      : <ArrowDown className="h-4 w-4 ml-1 text-primary" />;
  };

  const getThreatBadge = (level: string) => {
    switch(level) {
      case 'structural': return <Badge className="badge-danger text-xs">Structural</Badge>;
      case 'hybrid': return <Badge className="badge-danger text-xs">Hybrid</Badge>;
      case 'network': return <Badge className="badge-warning text-xs">Network</Badge>;
      case 'tactical': return <Badge className="badge-success text-xs">Tactical</Badge>;
      default: return <Badge className="text-xs">{level}</Badge>;
    }
  };

  const getCategoryBadge = (category: string) => {
    return category === 'digital-native' 
      ? <Badge variant="outline" className="text-primary border-primary text-xs">Digital-Native</Badge>
      : <Badge variant="outline" className="text-warning border-warning text-xs">Power Player</Badge>;
  };

  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <div className="bg-card border-b border-border">
        <div className="container py-6">
          <Link href="/">
            <Button variant="ghost" className="mb-4">
              <ArrowLeft className="mr-2 h-4 w-4" />
              Back to Dashboard
            </Button>
          </Link>
          
          <h1 className="text-4xl font-bold mb-2">All Companies</h1>
          <p className="text-muted-foreground">
            Comprehensive table view of {companies.length} TIC sector platforms
          </p>
        </div>
      </div>

      <div className="container py-8">
        {/* Filters */}
        <Card className="card-elevated p-6 mb-6">
          <div className="flex items-center gap-4 mb-4">
            <Filter className="h-5 w-5 text-muted-foreground" />
            <h3 className="font-semibold">Filters & Search</h3>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
            <div>
              <label className="text-sm text-muted-foreground mb-2 block">Search</label>
              <div className="relative">
                <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
                <Input
                  placeholder="Name, product, location..."
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  className="pl-9"
                />
              </div>
            </div>

            <div>
              <label className="text-sm text-muted-foreground mb-2 block">Category</label>
              <select
                value={selectedCategory}
                onChange={(e) => setSelectedCategory(e.target.value)}
                className="w-full h-10 px-3 rounded-md bg-input border border-border text-foreground"
              >
                <option value="all">All Categories</option>
                <option value="digital-native">Digital-Native</option>
                <option value="power-player">Power Players</option>
              </select>
            </div>

            <div>
              <label className="text-sm text-muted-foreground mb-2 block">Quadrant</label>
              <select
                value={selectedQuadrant}
                onChange={(e) => setSelectedQuadrant(e.target.value)}
                className="w-full h-10 px-3 rounded-md bg-input border border-border text-foreground"
              >
                <option value="all">All Quadrants</option>
                <option value="orchestrator">Orchestrators</option>
                <option value="data-engine">Data Engines</option>
                <option value="niche-expert">Niche Experts</option>
              </select>
            </div>

            <div>
              <label className="text-sm text-muted-foreground mb-2 block">Threat Level</label>
              <select
                value={selectedThreat}
                onChange={(e) => setSelectedThreat(e.target.value)}
                className="w-full h-10 px-3 rounded-md bg-input border border-border text-foreground"
              >
                <option value="all">All Threats</option>
                <option value="structural">Structural</option>
                <option value="hybrid">Hybrid</option>
                <option value="network">Network</option>
                <option value="tactical">Tactical</option>
              </select>
            </div>
          </div>
        </Card>

        {/* Results Count */}
        <div className="mb-4 text-sm text-muted-foreground">
          Showing {filteredAndSortedCompanies.length} of {companies.length} companies
        </div>

        {/* Table */}
        <Card className="card-elevated overflow-hidden">
          <div className="overflow-x-auto">
            <table className="w-full">
              <thead className="bg-muted/30 border-b border-border">
                <tr>
                  <th className="text-left p-4">
                    <Button 
                      variant="ghost" 
                      size="sm" 
                      onClick={() => handleSort('name')}
                      className="font-semibold hover:text-primary"
                    >
                      Company
                      <SortIcon field="name" />
                    </Button>
                  </th>
                  <th className="text-left p-4">
                    <Button 
                      variant="ghost" 
                      size="sm" 
                      onClick={() => handleSort('category')}
                      className="font-semibold hover:text-primary"
                    >
                      Category
                      <SortIcon field="category" />
                    </Button>
                  </th>
                  <th className="text-left p-4">
                    <Button 
                      variant="ghost" 
                      size="sm" 
                      onClick={() => handleSort('funding')}
                      className="font-semibold hover:text-primary"
                    >
                      Funding
                      <SortIcon field="funding" />
                    </Button>
                  </th>
                  <th className="text-left p-4">
                    <Button 
                      variant="ghost" 
                      size="sm" 
                      onClick={() => handleSort('headcount')}
                      className="font-semibold hover:text-primary"
                    >
                      Headcount
                      <SortIcon field="headcount" />
                    </Button>
                  </th>
                  <th className="text-left p-4">
                    <Button 
                      variant="ghost" 
                      size="sm" 
                      onClick={() => handleSort('quadrant')}
                      className="font-semibold hover:text-primary"
                    >
                      Quadrant
                      <SortIcon field="quadrant" />
                    </Button>
                  </th>
                  <th className="text-left p-4">
                    <Button 
                      variant="ghost" 
                      size="sm" 
                      onClick={() => handleSort('threat')}
                      className="font-semibold hover:text-primary"
                    >
                      Threat
                      <SortIcon field="threat" />
                    </Button>
                  </th>
                  <th className="text-right p-4">
                    <span className="font-semibold">Actions</span>
                  </th>
                </tr>
              </thead>
              <tbody>
                {filteredAndSortedCompanies.map((company) => (
                  <tr 
                    key={company.id} 
                    className="border-b border-border hover:bg-muted/20 transition-colors"
                  >
                    <td className="p-4">
                      <div>
                        <div className="font-semibold">{company.name}</div>
                        <div className="text-xs text-muted-foreground">{company.headquarters}</div>
                      </div>
                    </td>
                    <td className="p-4">
                      {getCategoryBadge(company.category)}
                    </td>
                    <td className="p-4">
                      <span className="font-mono text-success font-medium">{company.funding}</span>
                    </td>
                    <td className="p-4">
                      <span className="font-mono">{company.headcount}</span>
                    </td>
                    <td className="p-4">
                      <Badge variant="secondary" className="text-xs capitalize">
                        {company.quadrant.replace('-', ' ')}
                      </Badge>
                    </td>
                    <td className="p-4">
                      {getThreatBadge(company.threatLevel)}
                    </td>
                    <td className="p-4 text-right">
                      <Link href={`/company/${company.id}`}>
                        <Button variant="ghost" size="sm">
                          View
                          <ExternalLink className="ml-2 h-3 w-3" />
                        </Button>
                      </Link>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>

          {filteredAndSortedCompanies.length === 0 && (
            <div className="p-12 text-center text-muted-foreground">
              No companies match your filters
            </div>
          )}
        </Card>
      </div>
    </div>
  );
}
