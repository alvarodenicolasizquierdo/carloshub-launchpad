import { Link } from 'wouter';
import { Button } from '@/components/ui/button';
import { ArrowLeft, FileText } from 'lucide-react';
import { Streamdown } from 'streamdown';
import { useEffect, useState } from 'react';

export default function Report() {
  const [markdown, setMarkdown] = useState('');

  useEffect(() => {
    fetch('/consolidated_tic_report.md')
      .then(res => res.text())
      .then(text => setMarkdown(text))
      .catch(err => console.error('Failed to load report:', err));
  }, []);

  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <div className="bg-card border-b border-border sticky top-0 z-10">
        <div className="container py-4">
          <Link href="/">
            <Button variant="ghost" size="sm">
              <ArrowLeft className="mr-2 h-4 w-4" />
              Back to Dashboard
            </Button>
          </Link>
        </div>
      </div>

      <div className="container py-8">
        <div className="max-w-4xl mx-auto">
          <div className="mb-8 flex items-center gap-3">
            <FileText className="h-8 w-8 text-primary" />
            <div>
              <h1 className="text-3xl font-bold">Full Market Report</h1>
              <p className="text-muted-foreground">Comprehensive TIC sector analysis</p>
            </div>
          </div>

          <div className="prose prose-invert max-w-none">
            <style>{`
              .prose {
                color: oklch(0.92 0.01 240);
              }
              .prose h1 {
                color: oklch(0.98 0.01 240);
                font-size: 2.25rem;
                font-weight: 800;
                margin-top: 2rem;
                margin-bottom: 1rem;
                border-bottom: 2px solid oklch(0.25 0.03 240);
                padding-bottom: 0.5rem;
              }
              .prose h2 {
                color: oklch(0.95 0.01 240);
                font-size: 1.875rem;
                font-weight: 700;
                margin-top: 2rem;
                margin-bottom: 1rem;
              }
              .prose h3 {
                color: oklch(0.92 0.01 240);
                font-size: 1.5rem;
                font-weight: 600;
                margin-top: 1.5rem;
                margin-bottom: 0.75rem;
              }
              .prose h4 {
                color: oklch(0.90 0.01 240);
                font-size: 1.25rem;
                font-weight: 600;
                margin-top: 1.25rem;
                margin-bottom: 0.5rem;
              }
              .prose p {
                margin-top: 1rem;
                margin-bottom: 1rem;
                line-height: 1.75;
              }
              .prose a {
                color: oklch(0.55 0.20 230);
                text-decoration: underline;
              }
              .prose a:hover {
                color: oklch(0.65 0.20 230);
              }
              .prose strong {
                color: oklch(0.98 0.01 240);
                font-weight: 600;
              }
              .prose ul, .prose ol {
                margin-top: 1rem;
                margin-bottom: 1rem;
                padding-left: 1.5rem;
              }
              .prose li {
                margin-top: 0.5rem;
                margin-bottom: 0.5rem;
              }
              .prose table {
                width: 100%;
                margin-top: 1.5rem;
                margin-bottom: 1.5rem;
                border-collapse: collapse;
                background-color: oklch(0.18 0.03 240);
                border: 1px solid oklch(0.25 0.03 240);
                border-radius: 0.5rem;
                overflow: hidden;
              }
              .prose thead {
                background-color: oklch(0.22 0.03 240);
              }
              .prose th {
                padding: 0.75rem 1rem;
                text-align: left;
                font-weight: 600;
                color: oklch(0.95 0.01 240);
                border-bottom: 2px solid oklch(0.25 0.03 240);
              }
              .prose td {
                padding: 0.75rem 1rem;
                border-bottom: 1px solid oklch(0.22 0.03 240);
                color: oklch(0.85 0.01 240);
              }
              .prose tr:last-child td {
                border-bottom: none;
              }
              .prose tbody tr:hover {
                background-color: oklch(0.20 0.03 240);
              }
              .prose blockquote {
                border-left: 4px solid oklch(0.55 0.20 230);
                padding-left: 1rem;
                margin-left: 0;
                margin-right: 0;
                font-style: italic;
                color: oklch(0.75 0.01 240);
              }
              .prose code {
                background-color: oklch(0.22 0.03 240);
                padding: 0.2rem 0.4rem;
                border-radius: 0.25rem;
                font-size: 0.875rem;
                font-family: 'JetBrains Mono', monospace;
                color: oklch(0.75 0.15 85);
              }
              .prose pre {
                background-color: oklch(0.18 0.03 240);
                padding: 1rem;
                border-radius: 0.5rem;
                overflow-x: auto;
                border: 1px solid oklch(0.25 0.03 240);
              }
              .prose pre code {
                background-color: transparent;
                padding: 0;
              }
              .prose img {
                border-radius: 0.5rem;
                border: 1px solid oklch(0.25 0.03 240);
                margin-top: 1.5rem;
                margin-bottom: 1.5rem;
              }
              .prose hr {
                border-color: oklch(0.25 0.03 240);
                margin-top: 2rem;
                margin-bottom: 2rem;
              }
            `}</style>
            {markdown ? (
              <Streamdown>{markdown}</Streamdown>
            ) : (
              <div className="flex items-center justify-center py-12">
                <div className="text-center">
                  <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-primary mx-auto mb-4"></div>
                  <p className="text-muted-foreground">Loading report...</p>
                </div>
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}
