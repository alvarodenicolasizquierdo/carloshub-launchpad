import { useState } from 'react';
import { companies } from '@/data/companies';
import { Input } from '@/components/ui/input';
import { Badge } from '@/components/ui/badge';
import { Card } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { 
  Search, 
  TrendingUp, 
  Building2, 
  DollarSign, 
  Users, 
  Filter,
  BarChart3,
  FileText
} from 'lucide-react';
import { Link } from 'wouter';
import PositioningMatrix from '@/components/PositioningMatrix';

export default function Dashboard() {
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedCategory, setSelectedCategory] = useState<string>('all');
  const [selectedQuadrant, setSelectedQuadrant] = useState<string>('all');

  const filteredCompanies = companies.filter(company => {
    const matchesSearch = company.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
                         company.coreProduct.toLowerCase().includes(searchQuery.toLowerCase());
    const matchesCategory = selectedCategory === 'all' || company.category === selectedCategory;
    const matchesQuadrant = selectedQuadrant === 'all' || company.quadrant === selectedQuadrant;
    return matchesSearch && matchesCategory && matchesQuadrant;
  });

  const totalFunding = companies.reduce((sum, c) => sum + c.fundingAmount, 0);
  const totalHeadcount = companies.reduce((sum, c) => sum + c.headcountNumber, 0);
  const unicorns = companies.filter(c => c.valuation?.includes('Billion')).length;

  const getThreatBadge = (level: string) => {
    switch(level) {
      case 'structural': return <Badge className="badge-danger">Structural</Badge>;
      case 'hybrid': return <Badge className="badge-danger">Hybrid</Badge>;
      case 'network': return <Badge className="badge-warning">Network</Badge>;
      case 'tactical': return <Badge className="badge-success">Tactical</Badge>;
      default: return <Badge>{level}</Badge>;
    }
  };

  return (
    <div className="min-h-screen flex">
      {/* Sidebar */}
      <aside className="w-64 bg-sidebar border-r border-sidebar-border flex flex-col">
        <div className="p-6 border-b border-sidebar-border">
          <h1 className="text-xl font-bold text-sidebar-foreground">TIC Market Intel</h1>
          <p className="text-sm text-muted-foreground mt-1">Platform Database</p>
        </div>
        
        <nav className="flex-1 p-4 space-y-2">
          <Link href="/">
            <Button variant="default" className="w-full justify-start">
              <BarChart3 className="mr-2 h-4 w-4" />
              Dashboard
            </Button>
          </Link>
          <Link href="/companies">
            <Button variant="ghost" className="w-full justify-start text-sidebar-foreground">
              <Building2 className="mr-2 h-4 w-4" />
              Companies
            </Button>
          </Link>
          <Link href="/analysis">
            <Button variant="ghost" className="w-full justify-start text-sidebar-foreground">
              <TrendingUp className="mr-2 h-4 w-4" />
              Market Analysis
            </Button>
          </Link>
          <Link href="/report">
            <Button variant="ghost" className="w-full justify-start text-sidebar-foreground">
              <FileText className="mr-2 h-4 w-4" />
              Full Report
            </Button>
          </Link>
        </nav>

        <div className="p-4 border-t border-sidebar-border">
          <p className="text-xs text-muted-foreground">
            Data as of Feb 2026
          </p>
        </div>
      </aside>

      {/* Main Content */}
      <main className="flex-1 overflow-auto">
        <div className="container py-8">
          {/* Header */}
          <div className="mb-8">
            <h2 className="text-3xl font-bold mb-2">Market Overview</h2>
            <p className="text-muted-foreground">
              Comprehensive intelligence on TIC sector digital platforms
            </p>
          </div>

          {/* Key Metrics */}
          <div className="grid grid-cols-1 md:grid-cols-4 gap-4 mb-8">
            <Card className="card-elevated p-6">
              <div className="flex items-center justify-between mb-2">
                <DollarSign className="h-5 w-5 text-success" />
                <span className="text-xs text-muted-foreground">Total Funding</span>
              </div>
              <div className="text-2xl font-bold font-mono">${(totalFunding).toFixed(0)}M</div>
              <p className="text-xs text-muted-foreground mt-1">Across {companies.length} platforms</p>
            </Card>

            <Card className="card-elevated p-6">
              <div className="flex items-center justify-between mb-2">
                <Users className="h-5 w-5 text-primary" />
                <span className="text-xs text-muted-foreground">Total Headcount</span>
              </div>
              <div className="text-2xl font-bold font-mono">{totalHeadcount.toLocaleString()}</div>
              <p className="text-xs text-muted-foreground mt-1">Combined employees</p>
            </Card>

            <Card className="card-elevated p-6">
              <div className="flex items-center justify-between mb-2">
                <TrendingUp className="h-5 w-5 text-warning" />
                <span className="text-xs text-muted-foreground">Unicorns</span>
              </div>
              <div className="text-2xl font-bold font-mono">{unicorns}</div>
              <p className="text-xs text-muted-foreground mt-1">$1B+ valuations</p>
            </Card>

            <Card className="card-elevated p-6">
              <div className="flex items-center justify-between mb-2">
                <Building2 className="h-5 w-5 text-accent-foreground" />
                <span className="text-xs text-muted-foreground">Categories</span>
              </div>
              <div className="text-2xl font-bold font-mono">2</div>
              <p className="text-xs text-muted-foreground mt-1">Digital-Native + Power Players</p>
            </Card>
          </div>

          {/* Filters */}
          <Card className="card-elevated p-6 mb-6">
            <div className="flex items-center gap-4 mb-4">
              <Filter className="h-5 w-5 text-muted-foreground" />
              <h3 className="font-semibold">Filters</h3>
            </div>
            
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              <div>
                <label className="text-sm text-muted-foreground mb-2 block">Search</label>
                <div className="relative">
                  <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
                  <Input
                    placeholder="Company name or product..."
                    value={searchQuery}
                    onChange={(e) => setSearchQuery(e.target.value)}
                    className="pl-9"
                  />
                </div>
              </div>

              <div>
                <label className="text-sm text-muted-foreground mb-2 block">Category</label>
                <select
                  value={selectedCategory}
                  onChange={(e) => setSelectedCategory(e.target.value)}
                  className="w-full h-10 px-3 rounded-md bg-input border border-border text-foreground"
                >
                  <option value="all">All Categories</option>
                  <option value="digital-native">Digital-Native</option>
                  <option value="power-player">Power Players</option>
                </select>
              </div>

              <div>
                <label className="text-sm text-muted-foreground mb-2 block">Quadrant</label>
                <select
                  value={selectedQuadrant}
                  onChange={(e) => setSelectedQuadrant(e.target.value)}
                  className="w-full h-10 px-3 rounded-md bg-input border border-border text-foreground"
                >
                  <option value="all">All Quadrants</option>
                  <option value="orchestrator">Orchestrators</option>
                  <option value="data-engine">Data Engines</option>
                  <option value="niche-expert">Niche Experts</option>
                </select>
              </div>
            </div>
          </Card>

          {/* Positioning Matrix */}
          <div className="mb-8">
            <h3 className="text-2xl font-bold mb-4">Competitive Positioning Matrix</h3>
            <p className="text-muted-foreground mb-6">
              Companies positioned by workflow integration depth and network effects strength. Click any bubble to view details.
            </p>
            <PositioningMatrix />
          </div>

          {/* Companies Grid */}
          <h3 className="text-2xl font-bold mb-4">All Companies</h3>
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            {filteredCompanies.map((company) => (
              <Link key={company.id} href={`/company/${company.id}`}>
                <Card className="card-elevated p-6 hover:shadow-xl transition-shadow duration-300 cursor-pointer h-full">
                  <div className="flex items-start justify-between mb-4">
                    <div>
                      <h3 className="text-xl font-bold mb-1">{company.name}</h3>
                      <p className="text-sm text-muted-foreground">{company.headquarters}</p>
                    </div>
                    {getThreatBadge(company.threatLevel)}
                  </div>

                  <div className="space-y-3 mb-4">
                    <div className="flex justify-between items-center">
                      <span className="text-sm text-muted-foreground">Funding</span>
                      <span className="font-mono font-semibold text-success">{company.funding}</span>
                    </div>
                    <div className="flex justify-between items-center">
                      <span className="text-sm text-muted-foreground">Headcount</span>
                      <span className="font-mono font-semibold">{company.headcount}</span>
                    </div>
                    {company.valuation && (
                      <div className="flex justify-between items-center">
                        <span className="text-sm text-muted-foreground">Valuation</span>
                        <span className="font-mono font-semibold text-warning">{company.valuation}</span>
                      </div>
                    )}
                  </div>

                  <div className="pt-4 border-t border-border">
                    <p className="text-sm text-muted-foreground line-clamp-2">
                      {company.coreProduct}
                    </p>
                  </div>
                </Card>
              </Link>
            ))}
          </div>

          {filteredCompanies.length === 0 && (
            <Card className="card-elevated p-12 text-center">
              <p className="text-muted-foreground">No companies match your filters</p>
            </Card>
          )}
        </div>
      </main>
    </div>
  );
}
