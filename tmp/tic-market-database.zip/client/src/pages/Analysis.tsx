import { Link } from 'wouter';
import { Card } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { 
  ArrowLeft, 
  TrendingUp, 
  AlertTriangle,
  Target,
  DollarSign
} from 'lucide-react';
import { companies } from '@/data/companies';

export default function Analysis() {
  const orchestrators = companies.filter(c => c.quadrant === 'orchestrator');
  const dataEngines = companies.filter(c => c.quadrant === 'data-engine');
  const nicheExperts = companies.filter(c => c.quadrant === 'niche-expert');
  
  const structuralThreats = companies.filter(c => c.threatLevel === 'structural');
  const hybridThreats = companies.filter(c => c.threatLevel === 'hybrid');
  const networkThreats = companies.filter(c => c.threatLevel === 'network');
  const tacticalThreats = companies.filter(c => c.threatLevel === 'tactical');

  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <div className="bg-card border-b border-border">
        <div className="container py-6">
          <Link href="/">
            <Button variant="ghost" className="mb-4">
              <ArrowLeft className="mr-2 h-4 w-4" />
              Back to Dashboard
            </Button>
          </Link>
          
          <h1 className="text-4xl font-bold mb-2">Market Analysis</h1>
          <p className="text-muted-foreground">
            Strategic insights and competitive positioning in the TIC sector
          </p>
        </div>
      </div>

      <div className="container py-8 space-y-8">
        {/* Key Insights */}
        <Card className="card-elevated p-6">
          <h2 className="text-2xl font-bold mb-4 flex items-center">
            <TrendingUp className="mr-2 h-6 w-6 text-primary" />
            Executive Summary
          </h2>
          <div className="space-y-4 text-foreground">
            <p className="leading-relaxed">
              The TIC industry is undergoing a structural transformation from manual, periodic audits to continuous, AI-driven assurance. 
              While the traditional market grows at 3-5% CAGR, the digital-native platform segment is expanding at over 20% annually.
            </p>
            <p className="leading-relaxed">
              Our analysis reveals a market that is both more heavily capitalized and more concentrated than initially understood, 
              with significant funding discrepancies and critical omissions in standard market scans.
            </p>
          </div>
        </Card>

        {/* Funding Comparison Chart */}
        <Card className="card-elevated p-6">
          <h2 className="text-2xl font-bold mb-4 flex items-center">
            <DollarSign className="mr-2 h-6 w-6 text-success" />
            Funding Landscape
          </h2>
          <div className="mb-6">
            <img 
              src="/funding_comparison.png" 
              alt="TIC-Tech Funding: Gemini Claims vs Verified" 
              className="w-full rounded-lg border border-border"
            />
            <p className="text-sm text-muted-foreground mt-3">
              Source: Crunchbase, CB Insights, PitchBook, press releases | Feb 2026
            </p>
          </div>
          <p className="text-foreground leading-relaxed">
            Forensic analysis reveals material discrepancies between initial claims and verified funding data. 
            Altana AI's verified funding is nearly double what was initially reported, placing it in a different strategic weight class.
          </p>
        </Card>

        {/* VC Funding Trajectory */}
        <Card className="card-elevated p-6">
          <h2 className="text-2xl font-bold mb-4 flex items-center">
            <TrendingUp className="mr-2 h-6 w-6 text-warning" />
            Venture Capital Trajectory
          </h2>
          <div className="mb-6">
            <img 
              src="/tic_funding_trajectory.png" 
              alt="Supply Chain / TIC Tech VC Funding (2021-2025)" 
              className="w-full rounded-lg border border-border"
            />
            <p className="text-sm text-muted-foreground mt-3">
              Source: PitchBook, MicroVentures | 2025 projected from Q3 run-rate
            </p>
          </div>
          <p className="text-foreground leading-relaxed">
            After a peak in 2021 driven by the e-commerce boom, funding contracted in 2023 during the broader market reset. 
            Investment rebounded in 2024-2025 with clear focus on AI-native platforms capable of delivering tangible enterprise value.
          </p>
        </Card>

        {/* Major Omissions */}
        <Card className="card-elevated p-6">
          <h2 className="text-2xl font-bold mb-4 flex items-center">
            <AlertTriangle className="mr-2 h-6 w-6 text-danger" />
            Critical Market Omissions
          </h2>
          <div className="mb-6">
            <img 
              src="/omitted_competitors.png" 
              alt="Major Omissions: Employee Scale Comparison" 
              className="w-full rounded-lg border border-border"
            />
            <p className="text-sm text-muted-foreground mt-3">
              Companies missing from initial market scans | Verified headcount data
            </p>
          </div>
          <p className="text-foreground leading-relaxed mb-4">
            Initial market scans critically overlooked four major competitors who collectively represent over $600M in recent funding 
            and ~5,800 employees. QIMA, in particular, presents a unique threat by competing on both physical and digital fronts.
          </p>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div className="p-4 bg-muted/30 rounded-lg">
              <h3 className="font-bold mb-2">Assent Compliance</h3>
              <p className="text-sm text-muted-foreground">$501M funding, ~1,000 employees, $100M ARR</p>
            </div>
            <div className="p-4 bg-muted/30 rounded-lg">
              <h3 className="font-bold mb-2">QIMA</h3>
              <p className="text-sm text-muted-foreground">4,000+ employees, 32% revenue CAGR</p>
            </div>
            <div className="p-4 bg-muted/30 rounded-lg">
              <h3 className="font-bold mb-2">IntegrityNext</h3>
              <p className="text-sm text-muted-foreground">€100M funding, 200+ employees</p>
            </div>
            <div className="p-4 bg-muted/30 rounded-lg">
              <h3 className="font-bold mb-2">Sedex</h3>
              <p className="text-sm text-muted-foreground">95,000+ members, 540,000 audits</p>
            </div>
          </div>
        </Card>

        {/* Competitive Quadrants */}
        <Card className="card-elevated p-6">
          <h2 className="text-2xl font-bold mb-4 flex items-center">
            <Target className="mr-2 h-6 w-6 text-primary" />
            Competitive Positioning Matrix
          </h2>
          <p className="text-muted-foreground mb-6">
            Companies positioned by workflow integration depth and network effects strength
          </p>
          
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            <div>
              <h3 className="font-bold mb-3 flex items-center">
                <Badge className="badge-danger mr-2">Critical</Badge>
                The Orchestrators
              </h3>
              <p className="text-sm text-muted-foreground mb-3">
                High depth, high network effects. Act as "Operating System" for the industry.
              </p>
              <div className="space-y-2">
                {orchestrators.map(c => (
                  <Link key={c.id} href={`/company/${c.id}`}>
                    <div className="p-3 bg-muted/30 rounded hover:bg-muted/50 transition-colors cursor-pointer">
                      <div className="font-medium">{c.name}</div>
                      <div className="text-xs text-muted-foreground">{c.funding}</div>
                    </div>
                  </Link>
                ))}
              </div>
            </div>

            <div>
              <h3 className="font-bold mb-3 flex items-center">
                <Badge className="badge-warning mr-2">Moderate</Badge>
                The Data Engines
              </h3>
              <p className="text-sm text-muted-foreground mb-3">
                Low depth, high network effects. Provide intelligence other systems consume.
              </p>
              <div className="space-y-2">
                {dataEngines.map(c => (
                  <Link key={c.id} href={`/company/${c.id}`}>
                    <div className="p-3 bg-muted/30 rounded hover:bg-muted/50 transition-colors cursor-pointer">
                      <div className="font-medium">{c.name}</div>
                      <div className="text-xs text-muted-foreground">{c.funding}</div>
                    </div>
                  </Link>
                ))}
              </div>
            </div>

            <div>
              <h3 className="font-bold mb-3 flex items-center">
                <Badge className="badge-success mr-2">Focused</Badge>
                The Niche Experts
              </h3>
              <p className="text-sm text-muted-foreground mb-3">
                High depth, low network effects. Deep vertical solutions with high sector value.
              </p>
              <div className="space-y-2">
                {nicheExperts.map(c => (
                  <Link key={c.id} href={`/company/${c.id}`}>
                    <div className="p-3 bg-muted/30 rounded hover:bg-muted/50 transition-colors cursor-pointer">
                      <div className="font-medium">{c.name}</div>
                      <div className="text-xs text-muted-foreground">{c.funding}</div>
                    </div>
                  </Link>
                ))}
              </div>
            </div>
          </div>
        </Card>

        {/* Threat Assessment */}
        <Card className="card-elevated p-6">
          <h2 className="text-2xl font-bold mb-4 flex items-center">
            <AlertTriangle className="mr-2 h-6 w-6 text-danger" />
            Strategic Threat Assessment
          </h2>
          
          <div className="space-y-6">
            <div>
              <h3 className="font-bold mb-2 text-danger">Structural Threats ({structuralThreats.length})</h3>
              <p className="text-sm text-muted-foreground mb-3">
                Platform-level disruption that could make traditional per-test billing obsolete
              </p>
              <div className="space-y-2">
                {structuralThreats.map(c => (
                  <Link key={c.id} href={`/company/${c.id}`}>
                    <div className="p-3 bg-[oklch(0.65_0.22_25)]/10 border border-[oklch(0.65_0.22_25)]/30 rounded hover:bg-[oklch(0.65_0.22_25)]/20 transition-colors cursor-pointer">
                      <div className="font-medium">{c.name}</div>
                      <div className="text-xs text-muted-foreground mt-1">{c.strategicPosition.slice(0, 120)}...</div>
                    </div>
                  </Link>
                ))}
              </div>
            </div>

            <div>
              <h3 className="font-bold mb-2 text-danger">Hybrid Threats ({hybridThreats.length})</h3>
              <p className="text-sm text-muted-foreground mb-3">
                Competing on both physical inspection AND digital platform
              </p>
              <div className="space-y-2">
                {hybridThreats.map(c => (
                  <Link key={c.id} href={`/company/${c.id}`}>
                    <div className="p-3 bg-[oklch(0.65_0.22_25)]/10 border border-[oklch(0.65_0.22_25)]/30 rounded hover:bg-[oklch(0.65_0.22_25)]/20 transition-colors cursor-pointer">
                      <div className="font-medium">{c.name}</div>
                      <div className="text-xs text-muted-foreground mt-1">{c.strategicPosition.slice(0, 120)}...</div>
                    </div>
                  </Link>
                ))}
              </div>
            </div>

            <div>
              <h3 className="font-bold mb-2 text-warning">Network Threats ({networkThreats.length})</h3>
              <p className="text-sm text-muted-foreground mb-3">
                Achieved utility status; deeply embedded in procurement workflows
              </p>
              <div className="space-y-2">
                {networkThreats.map(c => (
                  <Link key={c.id} href={`/company/${c.id}`}>
                    <div className="p-3 bg-[oklch(0.75_0.15_85)]/10 border border-[oklch(0.75_0.15_85)]/30 rounded hover:bg-[oklch(0.75_0.15_85)]/20 transition-colors cursor-pointer">
                      <div className="font-medium">{c.name}</div>
                      <div className="text-xs text-muted-foreground mt-1">{c.strategicPosition.slice(0, 120)}...</div>
                    </div>
                  </Link>
                ))}
              </div>
            </div>

            <div>
              <h3 className="font-bold mb-2 text-success">Tactical Threats ({tacticalThreats.length})</h3>
              <p className="text-sm text-muted-foreground mb-3">
                Segment competition; potential acquisition targets
              </p>
              <div className="space-y-2">
                {tacticalThreats.map(c => (
                  <Link key={c.id} href={`/company/${c.id}`}>
                    <div className="p-3 bg-[oklch(0.65_0.18_155)]/10 border border-[oklch(0.65_0.18_155)]/30 rounded hover:bg-[oklch(0.65_0.18_155)]/20 transition-colors cursor-pointer">
                      <div className="font-medium">{c.name}</div>
                      <div className="text-xs text-muted-foreground mt-1">{c.strategicPosition.slice(0, 120)}...</div>
                    </div>
                  </Link>
                ))}
              </div>
            </div>
          </div>
        </Card>
      </div>
    </div>
  );
}
