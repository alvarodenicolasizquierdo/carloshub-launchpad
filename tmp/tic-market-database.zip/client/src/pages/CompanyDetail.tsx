import { useRoute, Link } from 'wouter';
import { companies } from '@/data/companies';
import { Card } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { 
  ArrowLeft, 
  Building2, 
  DollarSign, 
  Users, 
  TrendingUp,
  MapPin,
  Calendar,
  Target,
  AlertTriangle
} from 'lucide-react';

export default function CompanyDetail() {
  const [, params] = useRoute('/company/:id');
  const company = companies.find(c => c.id === params?.id);

  if (!company) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-background">
        <Card className="card-elevated p-8 text-center">
          <h2 className="text-2xl font-bold mb-2">Company Not Found</h2>
          <p className="text-muted-foreground mb-4">The requested company does not exist in our database.</p>
          <Link href="/">
            <Button>
              <ArrowLeft className="mr-2 h-4 w-4" />
              Back to Dashboard
            </Button>
          </Link>
        </Card>
      </div>
    );
  }

  const getThreatBadge = (level: string) => {
    switch(level) {
      case 'structural': return <Badge className="badge-danger text-base py-1 px-3">Structural Threat</Badge>;
      case 'hybrid': return <Badge className="badge-danger text-base py-1 px-3">Hybrid Threat</Badge>;
      case 'network': return <Badge className="badge-warning text-base py-1 px-3">Network Threat</Badge>;
      case 'tactical': return <Badge className="badge-success text-base py-1 px-3">Tactical Threat</Badge>;
      default: return <Badge className="text-base py-1 px-3">{level}</Badge>;
    }
  };

  const getCategoryBadge = (category: string) => {
    return category === 'digital-native' 
      ? <Badge variant="outline" className="text-primary border-primary">Digital-Native Disruptor</Badge>
      : <Badge variant="outline" className="text-warning border-warning">Overlooked Power Player</Badge>;
  };

  const getQuadrantLabel = (quadrant: string) => {
    const labels: Record<string, string> = {
      'orchestrator': 'The Orchestrators',
      'data-engine': 'The Data Engines',
      'niche-expert': 'The Niche Experts',
      'service-enabler': 'The Service Enablers'
    };
    return labels[quadrant] || quadrant;
  };

  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <div className="bg-card border-b border-border">
        <div className="container py-6">
          <Link href="/">
            <Button variant="ghost" className="mb-4">
              <ArrowLeft className="mr-2 h-4 w-4" />
              Back to Dashboard
            </Button>
          </Link>
          
          <div className="flex items-start justify-between">
            <div>
              <h1 className="text-4xl font-bold mb-3">{company.name}</h1>
              <div className="flex items-center gap-3 flex-wrap">
                {getCategoryBadge(company.category)}
                {getThreatBadge(company.threatLevel)}
                <Badge variant="secondary">{getQuadrantLabel(company.quadrant)}</Badge>
              </div>
            </div>
          </div>
        </div>
      </div>

      <div className="container py-8">
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          {/* Main Content */}
          <div className="lg:col-span-2 space-y-6">
            {/* Core Metrics */}
            <Card className="card-elevated p-6">
              <h2 className="text-xl font-bold mb-4 flex items-center">
                <TrendingUp className="mr-2 h-5 w-5 text-primary" />
                Key Metrics
              </h2>
              <div className="grid grid-cols-2 gap-6">
                <div>
                  <div className="text-sm text-muted-foreground mb-1">Total Funding</div>
                  <div className="text-2xl font-bold font-mono text-success">{company.funding}</div>
                </div>
                <div>
                  <div className="text-sm text-muted-foreground mb-1">Headcount</div>
                  <div className="text-2xl font-bold font-mono">{company.headcount}</div>
                </div>
                {company.valuation && (
                  <div>
                    <div className="text-sm text-muted-foreground mb-1">Valuation</div>
                    <div className="text-2xl font-bold font-mono text-warning">{company.valuation}</div>
                  </div>
                )}
                {company.revenue && (
                  <div>
                    <div className="text-sm text-muted-foreground mb-1">Revenue</div>
                    <div className="text-2xl font-bold font-mono">{company.revenue}</div>
                  </div>
                )}
              </div>
            </Card>

            {/* Strategic Position */}
            <Card className="card-elevated p-6">
              <h2 className="text-xl font-bold mb-4 flex items-center">
                <AlertTriangle className="mr-2 h-5 w-5 text-warning" />
                Strategic Position
              </h2>
              <p className="text-foreground leading-relaxed">
                {company.strategicPosition}
              </p>
            </Card>

            {/* Core Product */}
            <Card className="card-elevated p-6">
              <h2 className="text-xl font-bold mb-4 flex items-center">
                <Target className="mr-2 h-5 w-5 text-primary" />
                Core Product
              </h2>
              <p className="text-foreground text-lg">
                {company.coreProduct}
              </p>
            </Card>

            {/* Key Clients */}
            <Card className="card-elevated p-6">
              <h2 className="text-xl font-bold mb-4 flex items-center">
                <Building2 className="mr-2 h-5 w-5 text-accent-foreground" />
                Key Clients
              </h2>
              <div className="flex flex-wrap gap-2">
                {company.keyClients.map((client, idx) => (
                  <Badge key={idx} variant="secondary" className="text-sm py-1 px-3">
                    {client}
                  </Badge>
                ))}
              </div>
            </Card>
          </div>

          {/* Sidebar */}
          <div className="space-y-6">
            {/* Company Info */}
            <Card className="card-elevated p-6">
              <h3 className="font-bold mb-4">Company Information</h3>
              <div className="space-y-4">
                <div className="flex items-start gap-3">
                  <MapPin className="h-5 w-5 text-muted-foreground mt-0.5" />
                  <div>
                    <div className="text-sm text-muted-foreground">Headquarters</div>
                    <div className="font-medium">{company.headquarters}</div>
                  </div>
                </div>
                
                {company.founded && (
                  <div className="flex items-start gap-3">
                    <Calendar className="h-5 w-5 text-muted-foreground mt-0.5" />
                    <div>
                      <div className="text-sm text-muted-foreground">Founded</div>
                      <div className="font-medium">{company.founded}</div>
                    </div>
                  </div>
                )}

                {company.keyFunding && (
                  <div className="flex items-start gap-3">
                    <DollarSign className="h-5 w-5 text-muted-foreground mt-0.5" />
                    <div>
                      <div className="text-sm text-muted-foreground">Key Funding</div>
                      <div className="font-medium text-sm">{company.keyFunding}</div>
                    </div>
                  </div>
                )}

                <div className="flex items-start gap-3">
                  <Users className="h-5 w-5 text-muted-foreground mt-0.5" />
                  <div>
                    <div className="text-sm text-muted-foreground">Employee Range</div>
                    <div className="font-medium">{company.headcount}</div>
                  </div>
                </div>
              </div>
            </Card>

            {/* Competitive Positioning */}
            <Card className="card-elevated p-6">
              <h3 className="font-bold mb-4">Competitive Positioning</h3>
              <div className="space-y-3">
                <div>
                  <div className="text-sm text-muted-foreground mb-1">Quadrant</div>
                  <div className="font-medium">{getQuadrantLabel(company.quadrant)}</div>
                </div>
                <div>
                  <div className="text-sm text-muted-foreground mb-1">Threat Level</div>
                  <div className="font-medium capitalize">{company.threatLevel}</div>
                </div>
                <div>
                  <div className="text-sm text-muted-foreground mb-1">Category</div>
                  <div className="font-medium">
                    {company.category === 'digital-native' ? 'Digital-Native Disruptor' : 'Overlooked Power Player'}
                  </div>
                </div>
              </div>
            </Card>

            {/* Quick Actions */}
            <Card className="card-elevated p-6">
              <h3 className="font-bold mb-4">Quick Actions</h3>
              <div className="space-y-2">
                <Link href="/analysis">
                  <Button variant="outline" className="w-full justify-start">
                    <TrendingUp className="mr-2 h-4 w-4" />
                    View Market Analysis
                  </Button>
                </Link>
                <Link href="/report">
                  <Button variant="outline" className="w-full justify-start">
                    <Building2 className="mr-2 h-4 w-4" />
                    Read Full Report
                  </Button>
                </Link>
              </div>
            </Card>
          </div>
        </div>
      </div>
    </div>
  );
}
